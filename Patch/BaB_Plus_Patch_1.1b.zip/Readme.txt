- Get an ENGLISH original .bin of Blaze and Blade : Eternal Quest (This patch ONLY works with the English version of the game. Using it with any other version (French, German, etc.) will cause the game to crash on startup)
- Launch Patcher_Executable\ppf-o-matic3.exe , set the original .bin and the English patch BaB_Plus_Patch.ppf
- Apply patch
- Launch the patched bin via an ps1 emulator and enjoy !



Warning : Changes related to items (such as descriptions or auction prices) will NOT apply to items already obtained on an existing save state or memory card save. These changes will only affect newly looted items.
-----------------

If you encounter a crash or have ideas for improvement, feel free to send an email.
Contact: BroxxTeam@gmail.com